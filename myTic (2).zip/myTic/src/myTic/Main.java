package myTic;

import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

public class Main {
	Scanner scan;
	Vector<String> passengerNameList;
	Vector<String> airlinesTypeList;
	Vector<String> passengerDestinationList;
	Vector<String> seatClassList;
	Vector<String> scheduleList;
	Vector<Integer> airlinesPriceList;
	Vector<Integer> ticketQuantityList;
	Vector<String> username;
	Vector<String> password;
	

	public Main() {
		scan = new Scanner(System.in);
		passengerNameList = new Vector<>();
		airlinesTypeList = new Vector<>();
		passengerDestinationList = new Vector<>();
		seatClassList = new Vector<>();
		scheduleList = new Vector<>();
		airlinesPriceList = new Vector<>();
		ticketQuantityList = new Vector<>();
	    username = new Vector<>();
		password = new Vector<>();
	}
	
	public boolean checkCredential(Vector<String> username, Vector<String> password, String user, String pass) {
		for (int i = 0; i < username.size(); i++) {
			if (username.get(i).equals(user)) {
				if (password.get(i).equals(pass)) {
					return true;
			}else {
				return false;
			}
		}
	}
		return false;
	}
	
	void login() {
		String user;
		String pass;
		do {
			System.out.println("+-----------------------+");
			System.out.println("| \t  Login\t\t|");
			System.out.println("+-----------------------+");
			System.out.print("Username: ");
			user = scan.nextLine();
			
			System.out.print("Password: ");
			pass = scan.nextLine();
			
			if (!username.contains(user) || !password.contains(pass)) {
				System.err.println("Your username or password is wrong, please fill in again!\n");
			}
			boolean checkUser;
			checkUser = checkCredential(username, password, user, pass);
			if (checkUser == true) {
				System.out.println("\nLogin Success\n");
			}else {
				System.out.println("\nLogin Failed\n");
			}
		} while (!(username.contains(user) && password.contains(pass)));
	}
	
	void regis() {
		String user;
		String pass;
		
		do {
			System.out.println("\n+-----------------------+");
			System.out.println("| \tRegister\t|");
			System.out.println("+-----------------------+");
			System.out.print("Username: ");
			user = scan.nextLine();
			
			System.out.print("Password: ");
			pass = scan.nextLine();
			if (user.isEmpty() || pass.isEmpty()) {
				System.err.println("Please fill username and password!\n");
			}
		} while (user.isEmpty() || pass.isEmpty());
		
		System.out.println("\nYour account has been created.\n\n");
		
		username.add(user);
		password.add(pass);
		
		do {
			login();
		} while (!(username.contains(user) && password.contains(pass)));
	}
	
	void regisLogin() {
		String answer;
		do {
			System.out.println("+-----------------------+");
			System.out.println("| \t  myTic\t\t|");
			System.out.println("+-----------------------+");
			System.out.print("Do you already have an account [ Yes | No ] ?");
			System.out.print("\n>> ");
			answer = scan.nextLine();
			if (!(answer.equals("Yes") || answer.equals("No"))) {
				System.err.println("Please choose between Yes or No!\n");
			}
		} while (!(answer.equalsIgnoreCase("Yes") || answer.equalsIgnoreCase("No")));
		
		if (answer.equalsIgnoreCase("Yes")) {
			login();
		} else {
			regis();
		}
	}

	void run() {
		int input;
		regisLogin();
			do {
				printMenu();
				input = scanInt();
				switch (input) {
				case 1:
					bookATicket();
					break;
				case 2:
					listOfTicket();
					break;
				case 3:
					buyTicket();
					break;
				case 4:
					cancelTicket();
					break;
				case 5:
					System.out.println("\nThank you for using myTic");
					break;
				default: 
					System.err.println("[!] Input must be 1-5\n");	
					break;
					}
			} while (input != 5);
		}
		
	void printMenu() {
		System.out.println("+-----------------------+");
		System.out.println("| \t  myTic\t\t|");
		System.out.println("+-----------------------+");
		System.out.println("1. Book a Ticket");
		System.out.println("2. List of Ticket");
		System.out.println("3. Buy Ticket");
		System.out.println("4. Cancel Ticket");
		System.out.println("5. Exit");
		System.out.print("Choose >> ");
	}
	
	int scanInt() { 
		int input;
		try {
			input = scan.nextInt();
		}catch (Exception e) {
			input = Integer.MIN_VALUE; 
		}
		scan.nextLine();
		return input;
	}
	
	void bookATicket() {
		String type, destination, passengerName, seatClass, schedule = "";
		int quan, price = 0;
		do {
			System.out.print("\nChoose Airlines [ Garuda | Citilink | Lion Air | Batik Air] : ");
			type = scan.nextLine();
		} while (!type.equals("Garuda") && !type.equals("Citilink") && !type.equals("Lion Air") && !type.equals("Batik Air"));
		
		do {
			System.out.print("Choose destination [ Jakarta | Bali | Kalimantan | Sulawesi ]: "); 
			destination = scan.nextLine();
		} while(!destination.equals("Jakarta") && !destination.equals("Bali") && !destination.equals("Kalimantan") && !destination.equals("Sulawesi"));
		
		do {
			System.out.print("Input ticket's quantity [1..10]: ");
			quan = scanInt();
		}while(quan < 1 || quan > 10);
		
		SimpleDateFormat df = new SimpleDateFormat ("dd/MM/yyyy");
		boolean t = true;
		do {
			Date date;
			System.out.print("Choose flight schedule [dd/MM/yyyy] : ");
			schedule = scan.nextLine();
			try {
				date = df.parse(schedule);
			} catch (Exception e) {
				t = false;
			}
		} while (t == false); 
		
		do {
			System.out.print("Choose seat class [ First Class | Business Class | Economy Class ] : ");
			seatClass = scan.nextLine();
		} while (!seatClass.equals("First Class") && !seatClass.equals("Business Class") && !seatClass.equals("Economy Class"));
		
		do {
			System.out.print("Input passenger's name [5..20 Character] : ");
			passengerName = scan.nextLine();
		} while (passengerName.length() < 5 || passengerName.length() > 20);
		
		if (type.equals("Garuda") && destination.equals("Jakarta")) {
			if (seatClass.equals("Economy Class")) {
				price = 2000000;
			}else if (seatClass.equals("Business Class")) {
				price = 3500000;
			} else {
				price = 5500000;
			}
		}else if (type.equals("Garuda") && destination.equals("Bali")) {
			if (seatClass.equals("Economy Class")) {
				price = 3000000;
			}else if (seatClass.equals("Business Class")) {
				price = 4500000;
			} else {
				price = 6500000;
			}
		}else if (type.equals("Garuda") && destination.equals("Kalimantan")) {
			if (seatClass.equals("Economy Class")) {
				price = 3500000;
			}else if (seatClass.equals("Business Class")) {
				price = 4500000;
			} else {
				price = 5500000;
			}
		}else if (type.equals("Garuda") && destination.equals("Sulawesi")) {
			if (seatClass.equals("Economy Class")) {
				price = 4000000;
			}else if (seatClass.equals("Business Class")) {
				price = 5500000;
			} else {
				price = 7500000;
			}
		}
		
		if (type.equals("Citilink") && destination.equals("Jakarta")) {
			if (seatClass.equals("Economy Class")) {
				price = 1500000;
			}else if (seatClass.equals("Business Class")) {
				price = 2500000;
			} else {
				price = 4500000;
			}
		}else if (type.equals("Citilink") && destination.equals("Bali")) {
			if (seatClass.equals("Economy Class")) {
				price = 2000000;
			}else if (seatClass.equals("Business Class")) {
				price = 3500000;
			} else {
				price = 4550000;
			}
		}else if (type.equals("Citilink") && destination.equals("Kalimantan")) {
			if (seatClass.equals("Economy Class")) {
				price = 1500000;
			}else if (seatClass.equals("Business Class")) {
				price = 2500000;
			} else {
				price = 4500000;
			}
		}else if (type.equals("Citilink") && destination.equals("Sulawesi")) {
			if (seatClass.equals("Economy Class")) {
				price = 3000000;
			}else if (seatClass.equals("Business Class")) {
				price = 4500000;
			} else {
				price = 5500000;
			}
		}
		
		if (type.equals("Lion Air") && destination.equals("Jakarta")) {
			if (seatClass.equals("Economy Class")) {
				price = 1250000;
			}else if (seatClass.equals("Business Class")) {
				price = 3200000;
			}else {
				price = 4500000;
			}
		}else if (type.equals("Lion Air") && destination.equals("Bali")) {
			if (seatClass.equals("Economy Class")) {
				price = 2000000;
			}else if (seatClass.equals("Business Class")) {
				price = 3500000;
			} else {
				price = 4500000;
			}
		}else if (type.equals("Lion Air") && destination.equals("Kalimantan")) {
			if (seatClass.equals("Economy Class")) {
				price = 2000000;
			}else if (seatClass.equals("Business Class")) {
				price = 3550000;
			} else {
				price = 4550000;
			}
		}else if (type.equals("Lion Air") && destination.equals("Sulawesi")) {
			if (seatClass.equals("Economy Class")) {
				price = 3000000;
			}else if (seatClass.equals("Business Class")) {
				price = 4500000;
			} else {
				price = 5500000;
			}
		}
			
		if (type.equals("Batik Air")) {
			if (seatClass.equals("Economy Class")) {
				price = 1500000;
			}else if (seatClass.equals("Business Class")) {
				price = 2000000;
			}else {
				price = 3500000;
			}
		}else if (type.equals("Batik Air") && destination.equals("Bali")) {
			if (seatClass.equals("Economy Class")) {
				price = 2000000;
			}else if (seatClass.equals("Business Class")) {
				price = 3500000;
			} else {
				price = 5500000;
			}
		}else if (type.equals("Batik Air") && destination.equals("Kalimantan")) {
			if (seatClass.equals("Economy Class")) {
				price = 3500000;
			}else if (seatClass.equals("Business Class")) {
				price = 4500000;
			} else {
				price = 5500000;
			}
		}else if (type.equals("Batik Air") && destination.equals("Sulawesi")) {
			if (seatClass.equals("Economy Class")) {
				price = 4000000;
			}else if (seatClass.equals("Business Class")) {
				price = 5500000;
			} else {
				price = 6550000;
			}
		}

		airlinesTypeList.add(type);
		passengerDestinationList.add(destination);
		scheduleList.add(schedule);
		seatClassList.add(seatClass);
		passengerNameList.add(passengerName);
		ticketQuantityList.add(quan);
		airlinesPriceList.add(price);
		
		System.out.println("\nPress enter to continue...");
		scan.nextLine();
	}
	
	void sortTicket() {
		for (int i = 0; i < passengerNameList.size(); i++) {
	        for (int j = 0; j < passengerNameList.size()-1 -i; j++) {
	            if ((airlinesPriceList.get(j).compareTo(airlinesPriceList.get(j + 1))) > 0) {
	                int swapPrice = airlinesPriceList.get(j);
	                airlinesPriceList.set(j, airlinesPriceList.get(j + 1));
	                airlinesPriceList.set(j+1, swapPrice);
	                
	                String swapType = airlinesTypeList.get(j); 
	                airlinesTypeList.set(j, airlinesTypeList.get(j + 1));
	                airlinesTypeList.set(j+1, swapType);
	              
	                String swapName = passengerNameList.get(j);
	                passengerNameList.set(j, passengerNameList.get(j + 1));
	                passengerNameList.set(j+1, swapName);

	                String swapDestination = passengerDestinationList.get(j);
	                passengerDestinationList.set(j, passengerDestinationList.get(j + 1));
	                passengerDestinationList.set(j+1, swapDestination);
	                
	                String swapSchedule = scheduleList.get(j);
	                scheduleList.set(j, scheduleList.get(j + 1));
	                scheduleList.set(j+1, swapSchedule);
	                
	                String swapClass = seatClassList.get(j);
	                seatClassList.set(j, seatClassList.get(j + 1));
	                seatClassList.set(j+1, swapClass);
	                
	                int swapQuan = ticketQuantityList.get(j);
	                ticketQuantityList.set(j, ticketQuantityList.get(j + 1));
	                ticketQuantityList.set(j+1, swapQuan);
	                
	                
	            }
	         }
	     }
	}
	
	void listOfTicket() {
		if(passengerNameList.isEmpty()) {
			System.out.println("No Ticket Booked!");
			System.out.println("\nPress enter to continue");
			scan.nextLine();
		} else {
			sortTicket();
			System.out.println("\n================================================================================================================================================");
			System.out.printf("|| %-5s || %-15s || %-15s || %-15s || %-15s || %-15s || %-15s || %-15s ||\n", "No", "Type", "Destination", "Ticket Quantity", "Schedule", "Seat Class", "Name", "Price");
			System.out.println("================================================================================================================================================");
	
			for(int i = 0; i < airlinesTypeList.size(); i++) {
				System.out.printf("|| %-5s || %-15s || %-15s || %-15s || %-15s || %-15s || %-15s || %-15s ||\n", (i + 1), airlinesTypeList.get(i), passengerDestinationList.get(i), ticketQuantityList.get(i), scheduleList.get(i), seatClassList.get(i), passengerNameList.get(i), "Rp " + airlinesPriceList.get(i));
			}
			System.out.println("================================================================================================================================================");
			System.out.println("\nPress enter to continue...");
			scan.nextLine();
		}
	}
	
	void buyTicket() {
		if(passengerNameList.isEmpty()) {
			System.out.println("No Ticket Booked!");
		} else {
			sortTicket();
			int total = 0;
				System.out.println("\n================================================================================================================================================");
				System.out.printf("|| %-5s || %-15s || %-15s || %-15s || %-15s || %-15s || %-15s || %-15s ||\n", "No", "Type", "Destination", "Ticket Quantity", "Schedule", "Seat Class", "Name", "Price");
				System.out.println("================================================================================================================================================");
				for(int i = 0; i < passengerNameList.size(); i++) {
					int price = airlinesPriceList.get(i);
					int qty = ticketQuantityList.get(i);
					int subtotal = price * qty;
					total += subtotal; 
				System.out.printf("|| %-5s || %-15s || %-15s || %-15s || %-15s || %-15s || %-15s || %-15s ||\n", (i + 1), airlinesTypeList.get(i), passengerDestinationList.get(i), ticketQuantityList.get(i), scheduleList.get(i), seatClassList.get(i), passengerNameList.get(i), "Rp " + airlinesPriceList.get(i));
			}
			System.out.println("================================================================================================================================================");
			
			String buyAll;
			do {
				System.out.print("\nBuy All? [Y/N] : " );
				buyAll = scan.nextLine();
				}while(!buyAll.equals("Y") && !buyAll.equals("N"));
			
			if (buyAll.equals("Y")) {
				String payment;
				do {
					System.out.print("Choose payment method [Credit Card | OVO | Gopay | Mobile Banking] : ");
					payment = scan.nextLine();
				} while (!(payment.equals("Credit Card") || payment.equals("OVO") || payment.equals("Gopay") || payment.equals("Mobile Banking")));
			
				int discount = total * 10 / 100;
				int tax = total * 5 / 100;
				int grandTotal = total - discount + tax;
				System.out.println("\nTotal\t 		: Rp " + total);
				System.out.println("Discount [10%]\t 	: Rp " + discount);
				System.out.println("Tax [5%] 		: Rp " + tax);
				System.out.println("Grand Total	 	: Rp " + grandTotal);
				System.out.println("Thank you! | Terima Kasih!");	
				
				airlinesTypeList.removeAll(airlinesTypeList);
				passengerDestinationList.removeAll(passengerDestinationList); 
				ticketQuantityList.removeAll(ticketQuantityList); 
				scheduleList.removeAll(scheduleList);
				seatClassList.removeAll(seatClassList);
				passengerNameList.removeAll(passengerNameList); 
				airlinesPriceList.removeAll(airlinesPriceList);
				
			} else {
				return;
			}
		}
		System.out.println("\nPress enter to continue...");
		scan.nextLine();
	}
	
	void cancelTicket() {
		int number = 0;
		if(passengerNameList.isEmpty()) {
			System.out.println("No Ticket Booked!");
		} else {
			sortTicket();
			System.out.println("\n================================================================================================================================================");
			System.out.printf("|| %-5s || %-15s || %-15s || %-15s || %-15s || %-15s || %-15s || %-15s ||\n", "No", "Type", "Destination", "Ticket Quantity", "Schedule", "Seat Class", "Name", "Price");
			System.out.println("================================================================================================================================================");
			for(int i = 0; i < airlinesTypeList.size(); i++) {
				System.out.printf("|| %-5s || %-15s || %-15s || %-15s || %-15s || %-15s || %-15s || %-15s ||\n", (i + 1), airlinesTypeList.get(i), passengerDestinationList.get(i), ticketQuantityList.get(i), scheduleList.get(i), seatClassList.get(i), passengerNameList.get(i), "Rp " + airlinesPriceList.get(i));
			}
			System.out.println("================================================================================================================================================");
			
			do {
				System.out.print("Input number <No> to cancel [1.." + passengerNameList.size() + "] : ");
				try {
					number = scan.nextInt();
					number -= 1;
				} catch(Exception e) {
					System.out.println("Input must be numeric!");
				}
				scan.nextLine();
			} while(number < 0 || number > passengerNameList.size());
			
			airlinesTypeList.remove(airlinesTypeList.get(number));
			passengerNameList.remove(passengerNameList.get(number));
			ticketQuantityList.remove(ticketQuantityList.get(number));
			airlinesPriceList.remove(airlinesPriceList.get(number));
			passengerDestinationList.remove(number);
			scheduleList.remove(number);
			seatClassList.remove(number);

			System.out.println("Ticket Successfully Canceled!");
		}
		
			
			System.out.println("\nPress enter to continue...");
			scan.nextLine();
	}

	public static void main(String[] args) {
		Main main = new Main();
		main.run();

	}

}
